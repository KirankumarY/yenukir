package com.autocompletion.cities.AutoCompletioncities;

import static org.junit.Assert.assertEquals;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.autocompletion.cities.AutoCompletioncities.Service.MatchingCityService;

@RunWith(SpringRunner.class)
@SpringBootTest
public class AutoCompletioncitiesApplicationTests {

	@Test
	public void contextLoads() {
	}
	
	@Test
	public void checkTheMatchingCitiesfortheGivenprefix()
	{
		MatchingCityService matchingCityService = new MatchingCityService();
		matchingCityService.insert("visakhapatnam");
		
		assertEquals(true, matchingCityService.search("visakhapatnam"));
	}

}
