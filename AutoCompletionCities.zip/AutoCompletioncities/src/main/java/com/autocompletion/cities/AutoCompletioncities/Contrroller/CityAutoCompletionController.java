package com.autocompletion.cities.AutoCompletioncities.Contrroller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.autocompletion.cities.AutoCompletioncities.Service.MatchingCityService;

@RestController
public class CityAutoCompletionController {
	
	@Autowired
	MatchingCityService MatchingCityService;
	
	@GetMapping("/suggest_cities/{start}/{atmost}")
	public List<String> getCityNames(@PathVariable String start,@PathVariable String atmost)
	{
		
		int noOfCities = Integer.parseInt(atmost);
		return MatchingCityService.getTheMatchingCities(start,noOfCities);
		
	}
	
}
