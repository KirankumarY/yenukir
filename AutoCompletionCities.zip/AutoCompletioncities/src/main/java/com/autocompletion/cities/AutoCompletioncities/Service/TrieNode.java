package com.autocompletion.cities.AutoCompletioncities.Service;

class TrieNode {

	TrieNode[] arr;
    boolean isEnd;
    String val;
   
    public TrieNode() {
        this.arr = new TrieNode[26];
    }
    
    public TrieNode(String val) {
    	this.val = val;
        this.arr = new TrieNode[26];
    }
 
    
    public TrieNode[] getArr() {
		return arr;
	}
	public void setArr(TrieNode[] arr) {
		this.arr = arr;
	}
	public boolean isEnd() {
		return isEnd;
	}
	public void setEnd(boolean isEnd) {
		this.isEnd = isEnd;
	}
	public String getVal() {
		return val;
	}
	public void setVal(String val) {
		this.val = val;
	}
}
