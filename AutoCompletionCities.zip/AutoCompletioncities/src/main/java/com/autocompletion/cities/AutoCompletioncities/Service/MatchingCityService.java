package com.autocompletion.cities.AutoCompletioncities.Service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Service;

import com.autocompletion.cities.Exceptions.CityNotFound;

@Service
public class MatchingCityService {
	private TrieNode root;
	
	public MatchingCityService()
	{
		root = new TrieNode();
		intializetrieMap();
	}

	// Inserts a word into the trie.
	public void insert(String word) {

		word = word.toLowerCase();
		TrieNode p = root;
		for (int i = 0; i < word.length(); i++) {
			char c = word.charAt(i);
			
			if(c == '\u0000')
				continue;
			
			int index = (int) c - (int) 'a';
			if (p.arr[index] == null) {
				TrieNode temp = new TrieNode(c + "");
				p.arr[index] = temp;
				p = temp;
			} else {
				p = p.arr[index];
			}
		}
		p.isEnd = true;
	}

	// Returns if the word is in the trie.
	public boolean search(String word) {
		TrieNode p = searchNode(word);
		if (p == null) {
			return false;
		} else {
			if (p.isEnd)
				return true;
		}

		return false;
	}

	public TrieNode searchNode(String s) {
		TrieNode p = root;
		for (int i = 0; i < s.length(); i++) {
			char c = s.charAt(i);
			if(c == '\u0000')
				continue;
			
			int index = c - 'a';
			if (p.arr[index] != null) {
				p = p.arr[index];
			} else {
				return null;
			}
		}

		if (p == root)
			return null;

		return p;
	}

	public List<String> getTheMatchingCities(String s, int count) {
		TrieNode p = searchNode(s);

		List<String> matchedCities = new ArrayList<String>();
		if (p == null) {
			throw new CityNotFound("City Not Found");

		} else {
			matchedCities.addAll(getTheCityNames(p, s, count, new ArrayList<String>()));
		}

		return matchedCities;

	}

	private List<String> getTheCityNames(TrieNode p, String pattern, int count, List<String> arrayList) {

		if ((arrayList.size() <= count)) {
			for (TrieNode node : p.arr) {
				if (node == null || arrayList.size() >= count)
					continue;

				if (node.isEnd) {
					pattern = pattern + node.getVal();
					arrayList.add(pattern);
				} else {

					String updatedpattern = pattern + node.getVal();
					getTheCityNames(node, updatedpattern, count, arrayList);

				}
			}

		}

		return arrayList;
	}
	
	public void intializetrieMap()
	{
		insert("visakhapatnam");
		insert("vijayawada");
		insert("abdasa");
		insert("abhama");
		insert("abhanga");
		insert("abhanpur");
		insert("abhayapuri");
		insert("abiKarlpora");
		insert("aboahr");
		insert("abohar");
		insert("abuRoad");
		insert("aburoad");
	}

}